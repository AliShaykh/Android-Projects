package com.example.chattingapp

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class signup : AppCompatActivity() {
    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDBref:DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        var sign_up: Button =findViewById(R.id.log)
        var email: EditText =findViewById(R.id.username)
        var pass: EditText =findViewById(R.id.password)
        var name:EditText=findViewById(R.id.name)
        mAuth = FirebaseAuth.getInstance()

        sign_up.setOnClickListener({
            val e = email.text.toString()
            val p = pass.text.toString()
            val name= name.text.toString()
            signupp(name,e,p);

        })
    }

    private fun signupp(name: String, e: String, p: String) {
        mAuth.createUserWithEmailAndPassword(e, p)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                        addusertodatabase(name,e,mAuth.currentUser?.uid!!)
                    Toast.makeText(this, "Your account is created", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    finish()
                    startActivity(intent)
                } else {
                    Toast.makeText(this@signup,"Not created!", Toast.LENGTH_LONG).show()
                    // If sign in fails, display a message to the user.

                }
            }

    }

    private fun addusertodatabase(name: String, e: String, uid: String?) {
        mDBref = FirebaseDatabase.getInstance().getReference()
        if (uid != null) {
            mDBref.child("user").child(uid).setValue(user(name,e,uid))
        }
    }

}
