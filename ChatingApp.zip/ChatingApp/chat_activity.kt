package com.example.chattingapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.renderscript.Sampler
import android.widget.EditText
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class chat_activity : AppCompatActivity() {

    private lateinit var chatRecyclerview:RecyclerView
    private lateinit var messagebox: EditText
    private lateinit var sndbtn:ImageView
    private lateinit var messageadapter: MessageAdaper
    private lateinit var messagelist:ArrayList<Message>
    private lateinit var mDBref:DatabaseReference

    var recieverRoom:String?=null
    var senderroom:String?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        chatRecyclerview=findViewById(R.id.recycler2)
        messagebox = findViewById(R.id.msgbox)
        sndbtn = findViewById(R.id.imgsend)

        mDBref=FirebaseDatabase.getInstance().getReference()

        val name = intent.getStringExtra("name")
        val recieverUid = intent.getStringExtra("uid")
        val senderUid=FirebaseAuth.getInstance().currentUser?.uid

        senderroom=recieverUid+senderUid
        recieverRoom=senderUid+recieverUid

        supportActionBar?.title=name
        messagelist= ArrayList()
        messageadapter= MessageAdaper(this,messagelist)

        chatRecyclerview.layoutManager=LinearLayoutManager(this)
        chatRecyclerview.adapter=messageadapter

        mDBref.child("chats").child(senderroom!!).child("messages").addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                messagelist.clear()
                for(postSnapshot in snapshot.children){
                    val message=postSnapshot.getValue(Message::class.java)
                    messagelist.add(message!!)
                }
                messageadapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })

        sndbtn.setOnClickListener({
            val message=messagebox.text.toString()
            val messageObject=Message(message,senderUid)

            mDBref.child("chats").child(senderroom!!).child("messages").push().setValue(messageObject).addOnSuccessListener {
                mDBref.child("chats").child(recieverRoom!!).child("messages").push().setValue(messageObject)
            }
            messagebox.setText("")
        })

    }
}