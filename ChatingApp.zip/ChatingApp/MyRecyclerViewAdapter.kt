package com.example.chattingapp
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import java.util.ArrayList

class MyRecyclerViewAdatper(var context: Context, var userList: ArrayList<user>) : RecyclerView.Adapter<MyRecyclerViewAdatper.viewHolder>()
{

    class viewHolder(itemView: View): RecyclerView.ViewHolder(itemView)
    {
        var textname:TextView = itemView.findViewById(R.id.txt_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
//
        var myView = LayoutInflater.from(context).inflate(R.layout.user_layout, parent, false)
        return viewHolder(myView)
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
//
        //holder.textname.setText(""+userList.get(position).toString())
        //holder.textname.setText(userList.get(position).toString())
        val currentUser=userList[position]
        holder.textname.text = currentUser.name

        holder.itemView.setOnClickListener({
            val intent = Intent(context, chat_activity::class.java)
            intent.putExtra("name",currentUser.name)
            intent.putExtra("uid",currentUser.uid)
            context.startActivity(intent)
        })

    }

    override fun getItemCount(): Int {
//
        return userList.size
    }


}