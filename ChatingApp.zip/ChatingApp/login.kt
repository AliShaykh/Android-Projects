package com.example.chattingapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.ktx.Firebase

class login : AppCompatActivity() {

    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var log_in:Button=findViewById(R.id.log)
        var sign_up:Button=findViewById(R.id.sign)
        var email:EditText=findViewById(R.id.username)
        var pass:EditText=findViewById(R.id.password)

        sign_up.setOnClickListener({
            val intent = Intent(this, signup::class.java)
            startActivity(intent)
        })

        mAuth = FirebaseAuth.getInstance()

        log_in.setOnClickListener({
            val e = email.text.toString()
            val p = pass.text.toString()
            loginn(e,p);

        })

    }

    private fun loginn(e: String, p: String) {
        mAuth.signInWithEmailAndPassword(e, p)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Signed In", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    finish()
                    startActivity(intent)
                    // Sign in success, update UI with the signed-in user's information

                } else {
                    Toast.makeText(this, "User doesn't exist: ", Toast.LENGTH_SHORT).show()
                    // If sign in fails, display a message to the user.

                }
            }

    }
}