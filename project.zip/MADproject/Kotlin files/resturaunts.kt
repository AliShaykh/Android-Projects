package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class resturaunts : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resturaunts)


        var resList = listOf<String>("Bundu Khan", "Hardees", "Lahore broast", "Cafe jade", "Gloria jeans", "Mcdonalds", "KFC", "Pizza hut", "Burger Lab")
        var delList = listOf<String>("Delivery fee: 50" , "Delivery fee: 30", "Delivery fee: 10", "Delivery fee: 20", "Delivery fee: 60", "Delivery fee: free","Delivery fee: free", "Delivery fee: free", "Delivery fee: 5")
        var ratingList = listOf<String>("Rating:4*", "Rating:5*", "Rating:4.5*" , "Rating:4.8*", "Rating:4.1*", "Rating:4.2*", "Rating:3.8*", "Rating:3.5*", "Rating:5*", "Rating:4.8*")
        var imagesList = listOf<Int>(R.drawable.bundukhan, R.drawable.hardees,
            R.drawable.lahorebroast, R.drawable.cafejade, R.drawable.gloriajeans, R.drawable.mcdonals,
                    R.drawable.kfc, R.drawable.pizzahut, R.drawable.burgerlab)

        var myRecyView: RecyclerView = findViewById(R.id.myRecyclerView)

        myRecyView.layoutManager = LinearLayoutManager(this)
        var myRecyAdapter = MyRecyclerViewAdatper(this, imagesList, resList, ratingList, delList)
        myRecyView.adapter = myRecyAdapter


    }
}