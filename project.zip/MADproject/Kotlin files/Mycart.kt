package com.example.finalproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase

class Mycart : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mycart)

        var showcart: Button =findViewById(R.id.button8)
        var listview:ListView= findViewById(R.id.myListView)
        var mylistadapter:ArrayAdapter<String>?=null
        var datalist=ArrayList<String>()

        showcart.setOnClickListener({

            val database = Firebase.database
            val myRef = database.getReference("Food items")

            myRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (obj in snapshot.children) {
                        var temp = obj.getValue<MyDatabaseClass>()
                        Toast.makeText(
                            this@Mycart,
                            "Food items selected: ${temp?.food}",
                            Toast.LENGTH_SHORT
                        )
                        var currentfood:String="${temp?.food}"
                        datalist.add(currentfood)
                    }

                    mylistadapter=ArrayAdapter<String>(this@Mycart, android.R.layout.simple_list_item_1, datalist)
                    listview.adapter=mylistadapter
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@Mycart, "Operation cancelled", Toast.LENGTH_LONG).show()
                }
            })
        })
    }
}