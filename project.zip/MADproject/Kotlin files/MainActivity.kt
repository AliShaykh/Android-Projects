package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    var auth:FirebaseAuth?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var emailadd : EditText = findViewById(R.id.stdreg)
        var name : EditText = findViewById(R.id.stdname)
        var login:Button=findViewById(R.id.buttonlog)
        var register:Button=findViewById(R.id.buttonreg)
        var tv:TextView=findViewById(R.id.textView)

        auth=Firebase.auth

        var auth2:FirebaseAuth=Firebase.auth

        login.setOnClickListener({
            var stremail=emailadd.text.toString()
            var strpassword=name.text.toString()

            if(stremail.length<8)
            {
                Toast.makeText(MainActivity@this, "INvalid email ", Toast.LENGTH_SHORT).show()
                emailadd.requestFocus()
                emailadd.setError("Please provide a complete email")
            }
            if(strpassword.length<8)
            {
                Toast.makeText(MainActivity@this, "INvalid password", Toast.LENGTH_SHORT).show()
                name.requestFocus()
                name.setError("Please provide a password 8 characters atleast")
            }
            else
                auth2.signInWithEmailAndPassword(stremail, strpassword)
                    .addOnCompleteListener(this)
                    {

                            task ->
                        if (task.isSuccessful)
                        {
                            Toast.makeText(this, "Logged In", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, resturaunts::class.java))
                        }

                        else
                            Toast.makeText(this, "Can't log in, please check email or password: "+task.exception.toString(), Toast.LENGTH_SHORT).show()


                        emailadd.setText(null)
                        name.setText(null)

                    }

        })
        register.setOnClickListener({
            startActivity(Intent(this, Registeration::class.java))
        })
    }
}