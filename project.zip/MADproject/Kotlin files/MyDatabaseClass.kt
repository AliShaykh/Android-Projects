package com.example.finalproject

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.CursorAdapter
import android.widget.Toast

class MyDatabaseClass
{
    var food:String?=null

    fun insertObject(item:String)
    {
        food=item
    }

}