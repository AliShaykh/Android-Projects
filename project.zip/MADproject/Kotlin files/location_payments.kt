package com.example.finalproject

import android.Manifest
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import java.util.*

class location_payments : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_payments)

        val tv1: TextView = findViewById(R.id.textView3)
        val get: Button = findViewById(R.id.locbtn)

        ActivityCompat.requestPermissions(
            location_payments@ this,
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            569
        )


        val prog: ProgressDialog = ProgressDialog(location_payments@ this)
        prog.setMessage("Getting Your location...")
        prog.setTitle("Please wait")

        get.setOnClickListener({
            prog.show()

            val locManager : LocationManager = getSystemService(LOCATION_SERVICE) as LocationManager

            val locObject:MyLocationClass = MyLocationClass(tv1, prog)
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                Toast.makeText(this, "Permission denied by user", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0f, locObject)
        })

        ActivityCompat.requestPermissions(
            this,
            arrayOf(android.Manifest.permission.INTERNET),
            187
        )
        val etLat: EditText = findViewById(R.id.elat)
        val etlon: EditText = findViewById(R.id.elong)
        val display: TextView = findViewById(R.id.textView2)
        val geocode: Button = findViewById(R.id.addressbtn)

        geocode.setOnClickListener({
            val lat: Double = etLat.text.toString().toDouble()
            val lon: Double = etlon.text.toString().toDouble()

            val locationconverter: Geocoder = Geocoder(this, Locale.getDefault())
            val addr: List<Address> = locationconverter.getFromLocation(lat, lon, 1)
            val finalAdress = addr[0]

            val country: String = finalAdress.countryName
            val city = finalAdress.adminArea
            val subAdminArea = finalAdress.subAdminArea
            val name = finalAdress.featureName
            val addressLine = finalAdress.getAddressLine(0)

            val completeAddress =
                "Your address is: \nCountry: $country \n City : $city \nSubAdmin Area: $subAdminArea \nName: $name \n $addressLine"
            display.setText(completeAddress)
            Toast.makeText(this, "We have recieved your address, please confirm your order now!", Toast.LENGTH_LONG).show()

        })
        val final:Button=findViewById(R.id.confirmbtn)
        final.setOnClickListener({
            startActivity(Intent(this, Lastactivity::class.java))

        })

        fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
        ) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }
}