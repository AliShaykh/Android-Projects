package com.example.finalproject

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyRecyclerViewAdatperMenu(var context:Context,var imgList:List<Int>, var mList:List<String>,var modList: List<String>
                            ) : RecyclerView.Adapter<MyRecyclerViewAdatperMenu.viewHolder>()
{

    class viewHolder(itemView: View): RecyclerView.ViewHolder(itemView)
    {
        var imageView:ImageView = itemView.findViewById(R.id.imageView2)
        var tvPrice:TextView = itemView.findViewById(R.id.dishname)
        var tvManufecturer:TextView = itemView.findViewById(R.id.rupees)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
//        TODO("Not yet implemented")
        var myView = LayoutInflater.from(context).inflate(R.layout.custome_layout_menu, parent, false)
        return viewHolder(myView)
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
//        TODO("Not yet implemented")
        holder.imageView.setImageResource(imgList.get(position))
        holder.tvManufecturer.setText(mList.get(position))
        holder.tvPrice.setText(""+modList.get(position).toString())


        holder.imageView.setOnClickListener({

        })

    }

    override fun getItemCount(): Int {
//        TODO("Not yet implemented")
        return mList.size
    }


}