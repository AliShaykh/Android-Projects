package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase

class Menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        var dishnames = listOf<String>("Pizza", "zinger burger", "Shawarma","Pasta","BBQ","Chicken Karahi", "samosas", "Seekh kebab","Fish", "Sushi", "Chinese", "Beef steaks", "paratha roll", "yakhni pulao", "sajji", "ice cream", "club sandwich")
        var prices = listOf<String>("RS1000","RS250", "RS150", "RS300", "RS500", "RS1200", "RS25", "RS100", "RS800", "RS1800", "RS600", "RS1100", "RS250", "RS200", "RS350", "RS120", "RS450" )
        var imagelistt = listOf<Int>(R.drawable.pizza, R.drawable.burger, R.drawable.shawarma, R.drawable.pasta, R.drawable.bbq, R.drawable.karahi, R.drawable.samosa, R.drawable.kebab, R.drawable.fish, R.drawable.sushi, R.drawable.chinese, R.drawable.steaks, R.drawable.paratha, R.drawable.yakhni, R.drawable.sajii, R.drawable.icecream, R.drawable.sandwich )

        var myRecyView: RecyclerView = findViewById(R.id.myRecyclerView2)

        myRecyView.layoutManager = LinearLayoutManager(this)
        var myRecyAdapter = MyRecyclerViewAdatperMenu(this, imagelistt, dishnames, prices)
        myRecyView.adapter = myRecyAdapter

        var regno : EditText = findViewById(R.id.nameofdish)
        var addbutton:Button=findViewById(R.id.button4)
        var buybutton:Button=findViewById(R.id.button5)
        var cart:Button=findViewById(R.id.button6)


        addbutton.setOnClickListener({
            var strReg = regno.text.toString()
            var myDB:MyDatabaseClass= MyDatabaseClass()
            myDB.insertObject(strReg)

            val database = Firebase.database
            val myRef = database.getReference("Food items")

            myRef.child("Item_"+System.currentTimeMillis()).setValue(myDB)
                .addOnCompleteListener(this)
                {
                        task ->
                    if (task.isSuccessful)
                        Toast.makeText(this, "Food item added to cart", Toast.LENGTH_SHORT).show()
                    else
                        Toast.makeText(this, "Not added: "+task.exception.toString(), Toast.LENGTH_SHORT).show()


                    regno.setText(null)
                }

        })
        cart.setOnClickListener({
            startActivity(Intent(this, Mycart::class.java))



            })
        buybutton.setOnClickListener({
            startActivity(Intent(this, location_payments::class.java))

        })

    }
}