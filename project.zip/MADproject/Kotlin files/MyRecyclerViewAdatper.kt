package com.example.finalproject

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView


class MyRecyclerViewAdatper(var context:Context,var imgList:List<Int>, var mList:List<String>,var modList: List<String>,
                            var rsList: List<String>) : RecyclerView.Adapter<MyRecyclerViewAdatper.viewHolder>()
{

    class viewHolder(itemView: View): RecyclerView.ViewHolder(itemView)
    {
        var imageView:ImageView = itemView.findViewById(R.id.imageView)
        var tvPrice:TextView = itemView.findViewById(R.id.name)
        var tvManufecturer:TextView = itemView.findViewById(R.id.del)
        var tvModel:TextView = itemView.findViewById(R.id.rating)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
//        TODO("Not yet implemented")
        var myView = LayoutInflater.from(context).inflate(R.layout.custome_layout, parent, false)
        return viewHolder(myView)
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
//        TODO("Not yet implemented")
        holder.imageView.setImageResource(imgList.get(position))
        holder.tvPrice.setText(""+rsList.get(position).toString())
        holder.tvManufecturer.setText(mList.get(position))
        holder.tvModel.setText(modList.get(position))



        holder.imageView.setOnClickListener({
            var shifter : Intent = Intent(context, Menu::class.java)
            context.startActivity(shifter)

        })

    }

    override fun getItemCount(): Int {
//        TODO("Not yet implemented")
        return mList.size
    }


}