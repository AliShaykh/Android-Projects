package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class Registeration : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registeration)

        var password : EditText = findViewById(R.id.stdpass)
        var email : EditText = findViewById(R.id.stdEmail)

        var save : Button = findViewById(R.id.button)
        var readAll : Button = findViewById(R.id.button2)
        var shop : Button = findViewById(R.id.button3)


        val dbAuth: FirebaseAuth = Firebase.auth

        save.setOnClickListener({

            var stremail = email.text.toString()
            var strpass = password.text.toString()

            if(stremail.length<8)
            {
                Toast.makeText(this, "INvalid email ", Toast.LENGTH_SHORT).show()
                email.requestFocus()
                email.setError("Please provide a complete email")
            }
            if(strpass.length<8)
            {
                Toast.makeText(this, "INvalid password ", Toast.LENGTH_SHORT).show()
                email.requestFocus()
                email.setError("Please provide a complete password")
            }
            else
            {
                dbAuth.createUserWithEmailAndPassword(stremail, strpass)
                    .addOnCompleteListener(this)
                    {

                            task ->
                        if (task.isSuccessful)
                            Toast.makeText(this, "Your account is created", Toast.LENGTH_SHORT).show()
                        else
                            Toast.makeText(this, "Not created: "+task.exception.toString(), Toast.LENGTH_SHORT).show()


                        email.setText(null)
                        password.setText(null)

                    }
            }

        })
        //readAll.setOnClickListener({
          //  var db = MyDatabaseClass(this)
            //db.ReadAllRecords()

        //})

        shop.setOnClickListener({
            startActivity(Intent(this, resturaunts::class.java))
        })
       // DelButton.setOnClickListener({

         //   MyDatabaseClass(this).getdeletedData(delET.text.toString())
           // Toast.makeText(this,"Entered account is deleted!",Toast.LENGTH_LONG).show()
        //})
    }
}