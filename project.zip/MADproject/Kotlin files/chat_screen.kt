package com.example.finalproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.gsm.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat

class chat_screen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_screen)

        val phone: EditText = findViewById(R.id.editTextPhone)
        val smsBody:EditText = findViewById(R.id.editTextTextMultiLine)
        val sendButton: Button = findViewById(R.id.btnSend)


        sendButton.setOnClickListener({

            var version  = android.os.Build.VERSION.SDK_INT
            if(version>=23)
                ActivityCompat.requestPermissions(this,
                    arrayOf(android.Manifest.permission.SEND_SMS),
                    1132)

            // send your message here
            val strPhone = phone.text.toString()
            val strMessageBody = smsBody.text.toString()
            if (strPhone.length != 11) {
                Toast.makeText(this, "INvalid phone no", Toast.LENGTH_SHORT).show()
                phone.requestFocus()
                // this will highlight the phone text feild
                phone.setError("provided phone number is invalid")
                // will set an error message
            }
            else
            {
                val sender: SmsManager = SmsManager.getDefault()
                sender.sendTextMessage(strPhone, null,strMessageBody, null, null)



            }


        })



    }// oncreate

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if(grantResults[0] == PackageManager.PERMISSION_GRANTED)


    }

}