package com.example.finalproject

import android.app.ProgressDialog
import android.location.Location
import android.location.LocationListener
import android.os.Bundle
import android.widget.TextView

class MyLocationClass(var displayScreen:TextView, var prog:ProgressDialog) : LocationListener {

    val display:TextView = displayScreen
    val progress:ProgressDialog = prog

    override fun onProviderDisabled(provider: String) {
        super.onProviderDisabled(provider)
    }

    override fun onProviderEnabled(provider: String) {
        super.onProviderEnabled(provider)
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        super.onStatusChanged(provider, status, extras)
    }

    override fun onLocationChanged(location: Location) {

        prog.dismiss()
        display.setText("Your Location is: \nLatitude: ${location.latitude} \n Longitude: ${location.longitude}")

    }



}