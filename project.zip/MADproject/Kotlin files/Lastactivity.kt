package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Lastactivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lastactivity)

        var phnum: Button=findViewById(R.id.button7)
        var etnum:EditText=findViewById(R.id.editTextNumber)
        var tv5:TextView=findViewById(R.id.textView5)
        var tv4:TextView=findViewById(R.id.textView4)
        var chat:Button=findViewById(R.id.button9)

        phnum.setOnClickListener({
            Toast.makeText(Lastactivity@this, "Your entered phone number is inserted, thank you", Toast.LENGTH_SHORT).show()
        })
        chat.setOnClickListener({
            startActivity(Intent(this, chat_screen::class.java))
        })
    }
}